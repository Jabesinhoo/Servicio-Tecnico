// frontend/src/pages/Dashboard/Alquileres/components/NotificacionesCampana.jsx
import React, { useState, useRef, useEffect } from 'react';
import { Bell, Check, CheckCheck, X } from 'lucide-react';
import { useNotificaciones } from '../../../../hooks/useNotificaciones';

const NotificacionesCampana = () => {
    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef(null);
    const { notificaciones, noLeidas, cargarNotificaciones, marcarComoLeida, marcarTodasLeidas } = useNotificaciones();

    // Cerrar dropdown al hacer click fuera
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    // Recargar notificaciones al abrir
    useEffect(() => {
        if (isOpen) {
            cargarNotificaciones();
        }
    }, [isOpen]);

    const handleNotificacionClick = async (id, link) => {
        await marcarComoLeida(id);
        if (link) {
            window.location.href = link;
        }
        setIsOpen(false);
    };

    const getIconByTipo = (tipo) => {
        const icons = {
            solicitud: '📋',
            aprobacion: '✅',
            despacho: '📦',
            revision: '🔧',
            devolucion: '🔄',
            estado: '📌',
        };
        return icons[tipo] || '🔔';
    };

    return (
        <div className="relative" ref={dropdownRef}>
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="relative p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            >
                <Bell className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                {noLeidas > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center">
                        {noLeidas > 9 ? '9+' : noLeidas}
                    </span>
                )}
            </button>

            {isOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-gray-900 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700 z-50 max-h-96 overflow-hidden">
                    <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
                        <h3 className="text-sm font-semibold text-gray-900 dark:text-white">
                            Notificaciones
                            {noLeidas > 0 && (
                                <span className="ml-2 text-xs bg-red-500 text-white px-2 py-0.5 rounded-full">
                                    {noLeidas}
                                </span>
                            )}
                        </h3>
                        {noLeidas > 0 && (
                            <button
                                onClick={marcarTodasLeidas}
                                className="text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1"
                            >
                                <CheckCheck className="w-3 h-3" />
                                Marcar todas
                            </button>
                        )}
                    </div>

                    <div className="overflow-y-auto max-h-72">
                        {notificaciones.length === 0 ? (
                            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                                <Bell className="w-8 h-8 mx-auto mb-2 opacity-50" />
                                <p className="text-sm">No hay notificaciones</p>
                            </div>
                        ) : (
                            notificaciones.map((notif) => (
                                <div
                                    key={notif.id}
                                    onClick={() => handleNotificacionClick(notif.id, notif.link)}
                                    className={`px-4 py-3 border-b border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer transition-colors ${
                                        !notif.leido ? 'bg-blue-50 dark:bg-blue-900/10' : ''
                                    }`}
                                >
                                    <div className="flex items-start gap-3">
                                        <div className="text-xl">{getIconByTipo(notif.tipo)}</div>
                                        <div className="flex-1 min-w-0">
                                            <p className="text-sm font-medium text-gray-900 dark:text-white">
                                                {notif.titulo}
                                            </p>
                                            <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-2">
                                                {notif.mensaje}
                                            </p>
                                            <p className="text-xs text-gray-400 mt-1">
                                                {new Date(notif.created_at).toLocaleString()}
                                            </p>
                                        </div>
                                        {!notif.leido && (
                                            <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0 mt-1" />
                                        )}
                                    </div>
                                </div>
                            ))
                        )}
                    </div>

                    <div className="px-4 py-2 border-t border-gray-200 dark:border-gray-700 text-center">
                        <button
                            onClick={() => setIsOpen(false)}
                            className="text-xs text-gray-500 hover:text-gray-700"
                        >
                            Cerrar
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default NotificacionesCampana;