// frontend/src/pages/Dashboard/Alquileres/SolicitudList.jsx
import React, { useState } from 'react';
import { Eye, Calendar, User, FileText, Search, X } from 'lucide-react';
import AlquilerStatusBadge from './components/AlquilerStatusBadge';

const SolicitudList = ({ solicitudes, loading, onViewDetail, onRefresh }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [filterEstado, setFilterEstado] = useState('');

    const estados = ['pendiente', 'aprobado', 'rechazado', 'en_proceso', 'completado'];

    const filtered = solicitudes.filter(s => {
        const matchSearch = 
            s.numero_solicitud?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            s.cliente_nombre?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            s.cliente_documento?.includes(searchTerm);
        const matchEstado = filterEstado ? s.estado === filterEstado : true;
        return matchSearch && matchEstado;
    });

    if (loading) {
        return (
            <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
        );
    }

    return (
        <div className="space-y-4">
            {/* Filtros */}
            <div className="flex flex-col sm:flex-row gap-4">
                <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                        type="text"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        placeholder="Buscar por numero, cliente o documento..."
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                </div>
                <select
                    value={filterEstado}
                    onChange={(e) => setFilterEstado(e.target.value)}
                    className="px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                >
                    <option value="">Todos los estados</option>
                    {estados.map(estado => (
                        <option key={estado} value={estado}>
                            {estado.charAt(0).toUpperCase() + estado.slice(1)}
                        </option>
                    ))}
                </select>
                {filterEstado && (
                    <button
                        onClick={() => setFilterEstado('')}
                        className="px-3 py-2 text-red-500 hover:text-red-700"
                    >
                        <X className="w-4 h-4" />
                    </button>
                )}
            </div>

            {/* Tabla */}
            <div className="bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 overflow-hidden">
                {filtered.length === 0 ? (
                    <div className="text-center py-12 text-gray-500 dark:text-gray-400">
                        No hay solicitudes de alquiler
                    </div>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-800">
                            <thead className="bg-gray-50 dark:bg-gray-900">
                                <tr>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Solicitud</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Cliente</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Fechas</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Estado</th>
                                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Documentacion</th>
                                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">Acciones</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-800">
                                {filtered.map((solicitud) => (
                                    <tr key={solicitud.id} className="hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                                        <td className="px-6 py-4">
                                            <div className="text-sm font-medium text-gray-900 dark:text-white">
                                                {solicitud.numero_solicitud}
                                            </div>
                                            <div className="text-xs text-gray-500 dark:text-gray-400">
                                                Creado: {new Date(solicitud.created_at).toLocaleDateString()}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="text-sm text-gray-900 dark:text-white">
                                                {solicitud.cliente_nombre || '—'}
                                            </div>
                                            <div className="text-xs text-gray-500 dark:text-gray-400">
                                                {solicitud.cliente_documento || '—'}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="text-sm text-gray-600 dark:text-gray-400">
                                                Inicio: {new Date(solicitud.fecha_inicio).toLocaleDateString()}
                                            </div>
                                            <div className="text-sm text-gray-600 dark:text-gray-400">
                                                Fin: {new Date(solicitud.fecha_fin).toLocaleDateString()}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <AlquilerStatusBadge status={solicitud.estado} />
                                        </td>
                                        <td className="px-6 py-4">
                                            {solicitud.documentacion_aprobada ? (
                                                <span className="text-green-600 text-sm font-medium">Aprobada</span>
                                            ) : (
                                                <span className="text-yellow-600 text-sm font-medium">Pendiente</span>
                                            )}
                                        </td>
                                        <td className="px-6 py-4 text-right">
                                            <button
                                                onClick={() => onViewDetail(solicitud.id)}
                                                className="text-blue-600 hover:text-blue-800 dark:text-blue-400 p-1"
                                                title="Ver detalle"
                                            >
                                                <Eye className="w-4 h-4" />
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            <div className="text-sm text-gray-500 dark:text-gray-400 text-right">
                Total: {filtered.length} solicitudes
            </div>
        </div>
    );
};

export default SolicitudList;